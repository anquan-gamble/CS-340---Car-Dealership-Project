﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class CustInfo : Form
     {
          public CustInfo()
          {
               InitializeComponent();
          }

          private void CustInfo_Load(object sender, EventArgs e)
          {
              
          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          private void button2_Click(object sender, EventArgs e)
          {
               
               AddCust add = new AddCust();
               add.Show();
          }

          private void button3_Click(object sender, EventArgs e)
          {
               
               Cust cust = new Cust();
               cust.Show();
          }
     }
}
