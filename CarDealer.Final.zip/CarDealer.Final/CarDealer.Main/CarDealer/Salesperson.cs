﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class Salesperson : Form
     {
          public Salesperson()
          {
               InitializeComponent();
          }

          private void Salesperson_Load(object sender, EventArgs e)
          {
               textBox1.Text = "Welcome " + Login.recby;
          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
               ViewInventory inv = new ViewInventory();
               inv.ShowDialog();
               this.Show();
          }

          private void button2_Click(object sender, EventArgs e)
          {
               this.Hide();
               CustInfo man = new CustInfo();
               man.ShowDialog();
               this.Show();
          }

          private void button3_Click(object sender, EventArgs e)
          {
               this.Hide();
               ProcessPayment man = new ProcessPayment();
               man.ShowDialog();
               this.Show();
          }

          private void button4_Click(object sender, EventArgs e)
          {
               this.Hide();
               ViewYourSale man = new ViewYourSale();
               man.ShowDialog();
               this.Show();
          }

          private void button5_Click(object sender, EventArgs e)
          {
               this.Close();
               Login log = new Login();
               log.Show();
          }

          private void button6_Click(object sender, EventArgs e)
          {
               MessageBox.Show("View Inventory By Make and Model");
          }

          private void button7_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Add Customer and View Customers");
          }

          private void button8_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Process Payments");
          }

          private void button9_Click(object sender, EventArgs e)
          {
               MessageBox.Show("View Your Sales");
          }
     }
}
