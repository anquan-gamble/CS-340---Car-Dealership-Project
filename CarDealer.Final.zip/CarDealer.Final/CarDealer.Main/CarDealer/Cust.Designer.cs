﻿namespace CarDealer
{
     partial class Cust
     {
          /// <summary>
          /// Required designer variable.
          /// </summary>
          private System.ComponentModel.IContainer components = null;

          /// <summary>
          /// Clean up any resources being used.
          /// </summary>
          /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
          protected override void Dispose(bool disposing)
          {
               if (disposing && (components != null))
               {
                    components.Dispose();
               }
               base.Dispose(disposing);
          }

          #region Windows Form Designer generated code

          /// <summary>
          /// Required method for Designer support - do not modify
          /// the contents of this method with the code editor.
          /// </summary>
          private void InitializeComponent()
          {
               this.components = new System.ComponentModel.Container();
               this.dataGridView1 = new System.Windows.Forms.DataGridView();
               this.licenseNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.sexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.dateOfBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
               this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
               this.new_schemaDataSet1 = new CarDealer.new_schemaDataSet1();
               this.customerTableAdapter = new CarDealer.new_schemaDataSet1TableAdapters.customerTableAdapter();
               this.button1 = new System.Windows.Forms.Button();
               ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
               ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).BeginInit();
               this.SuspendLayout();
               // 
               // dataGridView1
               // 
               this.dataGridView1.AutoGenerateColumns = false;
               this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
               this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.licenseNumberDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.sexDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.dateOfBirthDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn});
               this.dataGridView1.DataSource = this.customerBindingSource;
               this.dataGridView1.Location = new System.Drawing.Point(41, 65);
               this.dataGridView1.Name = "dataGridView1";
               this.dataGridView1.RowTemplate.Height = 24;
               this.dataGridView1.Size = new System.Drawing.Size(992, 362);
               this.dataGridView1.TabIndex = 0;
               this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
               // 
               // licenseNumberDataGridViewTextBoxColumn
               // 
               this.licenseNumberDataGridViewTextBoxColumn.DataPropertyName = "License_Number";
               this.licenseNumberDataGridViewTextBoxColumn.FillWeight = 150F;
               this.licenseNumberDataGridViewTextBoxColumn.HeaderText = "License_Number";
               this.licenseNumberDataGridViewTextBoxColumn.Name = "licenseNumberDataGridViewTextBoxColumn";
               this.licenseNumberDataGridViewTextBoxColumn.Width = 150;
               // 
               // lastNameDataGridViewTextBoxColumn
               // 
               this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "Last_Name";
               this.lastNameDataGridViewTextBoxColumn.HeaderText = "Last_Name";
               this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
               // 
               // firstNameDataGridViewTextBoxColumn
               // 
               this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "First_Name";
               this.firstNameDataGridViewTextBoxColumn.HeaderText = "First_Name";
               this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
               // 
               // addressDataGridViewTextBoxColumn
               // 
               this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
               this.addressDataGridViewTextBoxColumn.FillWeight = 200F;
               this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
               this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
               // 
               // sexDataGridViewTextBoxColumn
               // 
               this.sexDataGridViewTextBoxColumn.DataPropertyName = "Sex";
               this.sexDataGridViewTextBoxColumn.HeaderText = "Sex";
               this.sexDataGridViewTextBoxColumn.Name = "sexDataGridViewTextBoxColumn";
               // 
               // phoneNumberDataGridViewTextBoxColumn
               // 
               this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_Number";
               this.phoneNumberDataGridViewTextBoxColumn.FillWeight = 150F;
               this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "Phone_Number";
               this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
               this.phoneNumberDataGridViewTextBoxColumn.Width = 150;
               // 
               // dateOfBirthDataGridViewTextBoxColumn
               // 
               this.dateOfBirthDataGridViewTextBoxColumn.DataPropertyName = "Date_Of_Birth";
               this.dateOfBirthDataGridViewTextBoxColumn.FillWeight = 120F;
               this.dateOfBirthDataGridViewTextBoxColumn.HeaderText = "Date_Of_Birth";
               this.dateOfBirthDataGridViewTextBoxColumn.Name = "dateOfBirthDataGridViewTextBoxColumn";
               this.dateOfBirthDataGridViewTextBoxColumn.Width = 120;
               // 
               // emailDataGridViewTextBoxColumn
               // 
               this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
               this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
               this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
               // 
               // customerBindingSource
               // 
               this.customerBindingSource.DataMember = "customer";
               this.customerBindingSource.DataSource = this.new_schemaDataSet1;
               // 
               // new_schemaDataSet1
               // 
               this.new_schemaDataSet1.DataSetName = "new_schemaDataSet1";
               this.new_schemaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
               // 
               // customerTableAdapter
               // 
               this.customerTableAdapter.ClearBeforeFill = true;
               // 
               // button1
               // 
               this.button1.Location = new System.Drawing.Point(13, 13);
               this.button1.Name = "button1";
               this.button1.Size = new System.Drawing.Size(129, 23);
               this.button1.TabIndex = 1;
               this.button1.Text = "Go Back";
               this.button1.UseVisualStyleBackColor = true;
               this.button1.Click += new System.EventHandler(this.button1_Click);
               // 
               // Cust
               // 
               this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
               this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
               this.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.ClientSize = new System.Drawing.Size(1064, 450);
               this.Controls.Add(this.button1);
               this.Controls.Add(this.dataGridView1);
               this.Name = "Cust";
               this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
               this.Text = "Cust";
               this.Load += new System.EventHandler(this.Cust_Load);
               ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
               ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).EndInit();
               this.ResumeLayout(false);

          }

          #endregion

          private System.Windows.Forms.DataGridView dataGridView1;
          private new_schemaDataSet1 new_schemaDataSet1;
          private System.Windows.Forms.BindingSource customerBindingSource;
          private new_schemaDataSet1TableAdapters.customerTableAdapter customerTableAdapter;
          private System.Windows.Forms.Button button1;
          private System.Windows.Forms.DataGridViewTextBoxColumn licenseNumberDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn sexDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn dateOfBirthDataGridViewTextBoxColumn;
          private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
     }
}