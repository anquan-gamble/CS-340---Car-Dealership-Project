﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class Cash : Form
     {
          MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
          
          public Cash()
          {
               InitializeComponent();
          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          private void textBox1_TextChanged(object sender, EventArgs e)
          {

          }

          private void Cash_Load(object sender, EventArgs e)
          {
               textBox1.Text = ViewInventory.rere;
               textBox4.Text = DateTime.Now.ToString("yyyy-MM-dd");
          }

          private void costVehicle_TextChanged(object sender, EventArgs e)
          {

          }

          private void textBox2_TextChanged(object sender, EventArgs e)
          {

          }

          private void tradeIn_TextChanged(object sender, EventArgs e)
          {

          }

          private void totalValue_TextChanged(object sender, EventArgs e)
          {

          }

          private void textBox3_TextChanged(object sender, EventArgs e)
          {

          }

          private void button2_Click(object sender, EventArgs e)
          {
               // Variables
               double costOfVehicle, tradeInValue, total;
               

               // Inputs
               costOfVehicle = Convert.ToDouble(costVehicle.Text);
               
               if (string.IsNullOrEmpty(tradeIn.Text))
               {
                    tradeInValue = 0;
               }
               else
                    tradeInValue = Convert.ToDouble(tradeIn.Text);
               // Calculation
               total = costOfVehicle - tradeInValue;

               // Show outputs
               costVehicle.Text = costOfVehicle.ToString("c");
               tradeIn.Text = tradeInValue.ToString("c");
               totalValue.Text = total.ToString("c");

               
          }

          private void button3_Click(object sender, EventArgs e)
          {
               string cash, Year, Make, Model, Price, CFN, CLN, EFN, ELN;
               cash = "Cash";
               
               
               MySqlCommand command = new MySqlCommand("SELECT * FROM inventory WHERE VIN = '" + textBox1.Text + "'", con);
               
               DataTable dt = new DataTable();
               MySqlDataReader reader = command.ExecuteReader();
               reader.Read();
               
               Year = reader["Year"].ToString();
               Make = reader["Make"].ToString();
               Model = reader["Model"].ToString();
               Price = reader["MSRP"].ToString();
               reader.Close();
               
               MySqlCommand command1 = new MySqlCommand("SELECT * FROM customer WHERE License_Number = '" + textBox2.Text + "'", con);
               
               DataTable dtt = new DataTable();
               MySqlDataReader reader1 = command1.ExecuteReader();
               reader1.Read();
               CFN = reader1["First_Name"].ToString();
               CLN = reader1["Last_Name"].ToString();
               reader1.Close();

               MySqlCommand command2 = new MySqlCommand("SELECT * FROM employee WHERE Employee_ID = '" + Login.recby + "'", con);
               
               MySqlDataReader reader2 = command2.ExecuteReader();
               reader2.Read();
               EFN = reader2["First_Name"].ToString();
               ELN = reader2["Last_Name"].ToString();
               reader2.Close();

               MySqlCommand cmd1 = new MySqlCommand("DELETE FROM inventory WHERE VIN = '" + textBox1.Text + "'", con);
               MySqlDataReader reader3 = cmd1.ExecuteReader();
               reader3.Read();
               reader3.Close();

               MySqlCommand cmd2 = new MySqlCommand("UPDATE employee SET Total_Car_Sales = Total_Car_Sales + 1 WHERE Employee_ID = '" + Login.recby + "'", con);
               MySqlDataReader reader4 = cmd2.ExecuteReader();
               reader4.Read();
               reader4.Close();
               


               MySqlCommand cmd = new MySqlCommand();
               cmd.CommandText = "INSERT INTO receipt (`Transaction_Method`, `VIN`, `Year`, `Make`, `Model`, `Price`, `Customer_First_Name`, `Customer_Last_Name`,`License_Number`, `Employee_ID`, `Employee_First_Name`, `Employee_Last_Name`, `Date`) VALUES ('"+ cash +"' , '" + textBox1.Text + "' , '"+ Year + "', '"+ Make + "' , '" + Model + "', '" + Price + "', '" +CFN+ "', '" +CLN+ "', '" + textBox2.Text + "', '" + Login.recby + "', '"+ EFN+ "', '"+ELN+"', '" + textBox4.Text+ "')";
               cmd.Connection = con;
               int a = cmd.ExecuteNonQuery();
               
               if (a > 0)
               {
                    MessageBox.Show("Payment Processed. Invoice Created.");
               }
               
               con.Close();
               
          }

          private void button4_Click(object sender, EventArgs e)
          {
               con.Open();
               MySqlCommand command = new MySqlCommand("SELECT * FROM inventory WHERE VIN = '" + textBox1.Text + "'", con);
               MySqlDataAdapter da = new MySqlDataAdapter(command);
               DataTable dt = new DataTable();
               da.Fill(dt);
               foreach (DataRow dr in dt.Rows)
               {
                    costVehicle.Text = dr["MSRP"].ToString();
                    
               }
          }
     }
}
