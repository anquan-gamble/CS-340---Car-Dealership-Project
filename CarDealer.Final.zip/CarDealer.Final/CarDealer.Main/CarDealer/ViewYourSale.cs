﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class ViewYourSale : Form
     {
          public ViewYourSale()
          {
               InitializeComponent();
          }
          private DataTable GetInventoryList()
          {
               MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
               con.Open();
               MySqlCommand command = new MySqlCommand("SELECT * FROM receipt WHERE Employee_ID = '" + Login.recby + "' ", con);
               DataTable dt = new DataTable();
               MySqlDataReader reader = command.ExecuteReader();
               dt.Load(reader);
               return dt;
          }
          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          private void ViewYourSale_Load(object sender, EventArgs e)
          {
               dataGridView1.DataSource = GetInventoryList();
          }
     }
}
