﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class MainMan : Form
     {
          public MainMan()
          {
               InitializeComponent();
          }

          private void MainMan_Load(object sender, EventArgs e)
          {
               textBox1.Text = "Welcome " + Login.recby;

          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
               ViewInventory man = new ViewInventory();
               man.ShowDialog();
               this.Show();
          }

          private void button2_Click(object sender, EventArgs e)
          {
               this.Hide();
               CustInfo man = new CustInfo();
               man.ShowDialog();
               this.Show();
          }
          private void button3_Click(object sender, EventArgs e)
          {
               this.Hide();
               ProcessPayment man = new ProcessPayment();
               man.ShowDialog();
               this.Show();
          }

          private void button4_Click(object sender, EventArgs e)
          {
               this.Hide();
               ViewSalesAll man = new ViewSalesAll();
               man.ShowDialog();
               this.Show();
          }

          private void button5_Click(object sender, EventArgs e)
          {
               this.Hide();
               Payroll man = new Payroll();
               man.ShowDialog();
               this.Show();
          }

          private void button6_Click(object sender, EventArgs e)
          {
               this.Hide();
               ManIn man = new ManIn();
               man.ShowDialog();
               this.Show();
          }

          private void fillByToolStripButton_Click(object sender, EventArgs e)
          {
               try
               {
                    this.loginTableAdapter.FillBy(this.new_schemaDataSet.login);
               }
               catch (System.Exception ex)
               {
                    System.Windows.Forms.MessageBox.Show(ex.Message);
               }

          }

          private void button7_Click(object sender, EventArgs e)
          {
               this.Close();
               Login log = new Login();
               log.Show();
          }

          private void label1_Click(object sender, EventArgs e)
          {

          }

          private void button8_Click(object sender, EventArgs e)
          {
               MessageBox.Show("View Inventory By Make and Model");
          }

          private void button9_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Add Customer and View Customers");
          }

          private void button10_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Process Payments");
          }

          private void button11_Click(object sender, EventArgs e)
          {
               MessageBox.Show("View Sales of All Employees");
          }

          private void button12_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Manage Employees and Calculate Pay");
          }

          private void button13_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Add and Remove Cars from Inventory");
          }
     }
}
