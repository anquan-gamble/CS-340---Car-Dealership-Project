﻿namespace CarDealer
{
     partial class Salesperson
     {
          /// <summary>
          /// Required designer variable.
          /// </summary>
          private System.ComponentModel.IContainer components = null;

          /// <summary>
          /// Clean up any resources being used.
          /// </summary>
          /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
          protected override void Dispose(bool disposing)
          {
               if (disposing && (components != null))
               {
                    components.Dispose();
               }
               base.Dispose(disposing);
          }

          #region Windows Form Designer generated code

          /// <summary>
          /// Required method for Designer support - do not modify
          /// the contents of this method with the code editor.
          /// </summary>
          private void InitializeComponent()
          {
               this.components = new System.ComponentModel.Container();
               this.button1 = new System.Windows.Forms.Button();
               this.button2 = new System.Windows.Forms.Button();
               this.button3 = new System.Windows.Forms.Button();
               this.button4 = new System.Windows.Forms.Button();
               this.button5 = new System.Windows.Forms.Button();
               this.new_schemaDataSet1 = new CarDealer.new_schemaDataSet1();
               this.loginBindingSource = new System.Windows.Forms.BindingSource(this.components);
               this.loginTableAdapter = new CarDealer.new_schemaDataSet1TableAdapters.loginTableAdapter();
               this.textBox1 = new System.Windows.Forms.TextBox();
               this.button6 = new System.Windows.Forms.Button();
               this.button7 = new System.Windows.Forms.Button();
               this.button8 = new System.Windows.Forms.Button();
               this.button9 = new System.Windows.Forms.Button();
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).BeginInit();
               ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).BeginInit();
               this.SuspendLayout();
               // 
               // button1
               // 
               this.button1.Location = new System.Drawing.Point(225, 50);
               this.button1.Name = "button1";
               this.button1.Size = new System.Drawing.Size(300, 50);
               this.button1.TabIndex = 0;
               this.button1.Text = "View Inventory";
               this.button1.UseVisualStyleBackColor = true;
               this.button1.Click += new System.EventHandler(this.button1_Click);
               // 
               // button2
               // 
               this.button2.Location = new System.Drawing.Point(225, 150);
               this.button2.Name = "button2";
               this.button2.Size = new System.Drawing.Size(300, 50);
               this.button2.TabIndex = 1;
               this.button2.Text = "Customer Information";
               this.button2.UseVisualStyleBackColor = true;
               this.button2.Click += new System.EventHandler(this.button2_Click);
               // 
               // button3
               // 
               this.button3.Location = new System.Drawing.Point(225, 250);
               this.button3.Name = "button3";
               this.button3.Size = new System.Drawing.Size(300, 50);
               this.button3.TabIndex = 2;
               this.button3.Text = "Process Payment";
               this.button3.UseVisualStyleBackColor = true;
               this.button3.Click += new System.EventHandler(this.button3_Click);
               // 
               // button4
               // 
               this.button4.Location = new System.Drawing.Point(225, 350);
               this.button4.Name = "button4";
               this.button4.Size = new System.Drawing.Size(300, 50);
               this.button4.TabIndex = 3;
               this.button4.Text = "View Your Sale";
               this.button4.UseVisualStyleBackColor = true;
               this.button4.Click += new System.EventHandler(this.button4_Click);
               // 
               // button5
               // 
               this.button5.Location = new System.Drawing.Point(12, 401);
               this.button5.Name = "button5";
               this.button5.Size = new System.Drawing.Size(108, 37);
               this.button5.TabIndex = 4;
               this.button5.Text = "Log Out";
               this.button5.UseVisualStyleBackColor = true;
               this.button5.Click += new System.EventHandler(this.button5_Click);
               // 
               // new_schemaDataSet1
               // 
               this.new_schemaDataSet1.DataSetName = "new_schemaDataSet1";
               this.new_schemaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
               // 
               // loginBindingSource
               // 
               this.loginBindingSource.DataMember = "login";
               this.loginBindingSource.DataSource = this.new_schemaDataSet1;
               // 
               // loginTableAdapter
               // 
               this.loginTableAdapter.ClearBeforeFill = true;
               // 
               // textBox1
               // 
               this.textBox1.AcceptsReturn = true;
               this.textBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
               this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
               this.textBox1.ForeColor = System.Drawing.Color.White;
               this.textBox1.Location = new System.Drawing.Point(12, 13);
               this.textBox1.Name = "textBox1";
               this.textBox1.ReadOnly = true;
               this.textBox1.Size = new System.Drawing.Size(152, 17);
               this.textBox1.TabIndex = 5;
               // 
               // button6
               // 
               this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
               this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button6.Location = new System.Drawing.Point(568, 50);
               this.button6.Name = "button6";
               this.button6.Size = new System.Drawing.Size(38, 50);
               this.button6.TabIndex = 6;
               this.button6.Text = "?";
               this.button6.UseVisualStyleBackColor = false;
               this.button6.Click += new System.EventHandler(this.button6_Click);
               // 
               // button7
               // 
               this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
               this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button7.Location = new System.Drawing.Point(568, 150);
               this.button7.Name = "button7";
               this.button7.Size = new System.Drawing.Size(38, 50);
               this.button7.TabIndex = 7;
               this.button7.Text = "?";
               this.button7.UseVisualStyleBackColor = false;
               this.button7.Click += new System.EventHandler(this.button7_Click);
               // 
               // button8
               // 
               this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
               this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button8.Location = new System.Drawing.Point(568, 250);
               this.button8.Name = "button8";
               this.button8.Size = new System.Drawing.Size(38, 50);
               this.button8.TabIndex = 8;
               this.button8.Text = "?";
               this.button8.UseVisualStyleBackColor = false;
               this.button8.Click += new System.EventHandler(this.button8_Click);
               // 
               // button9
               // 
               this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
               this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button9.Location = new System.Drawing.Point(568, 350);
               this.button9.Name = "button9";
               this.button9.Size = new System.Drawing.Size(38, 50);
               this.button9.TabIndex = 9;
               this.button9.Text = "?";
               this.button9.UseVisualStyleBackColor = false;
               this.button9.Click += new System.EventHandler(this.button9_Click);
               // 
               // Salesperson
               // 
               this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
               this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
               this.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.ClientSize = new System.Drawing.Size(800, 450);
               this.Controls.Add(this.button9);
               this.Controls.Add(this.button8);
               this.Controls.Add(this.button7);
               this.Controls.Add(this.button6);
               this.Controls.Add(this.textBox1);
               this.Controls.Add(this.button5);
               this.Controls.Add(this.button4);
               this.Controls.Add(this.button3);
               this.Controls.Add(this.button2);
               this.Controls.Add(this.button1);
               this.Name = "Salesperson";
               this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
               this.Text = "Salesperson";
               this.Load += new System.EventHandler(this.Salesperson_Load);
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).EndInit();
               ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).EndInit();
               this.ResumeLayout(false);
               this.PerformLayout();

          }

          #endregion

          private System.Windows.Forms.Button button1;
          private System.Windows.Forms.Button button2;
          private System.Windows.Forms.Button button3;
          private System.Windows.Forms.Button button4;
          private System.Windows.Forms.Button button5;
          private new_schemaDataSet1 new_schemaDataSet1;
          private System.Windows.Forms.BindingSource loginBindingSource;
          private new_schemaDataSet1TableAdapters.loginTableAdapter loginTableAdapter;
          private System.Windows.Forms.TextBox textBox1;
          private System.Windows.Forms.Button button6;
          private System.Windows.Forms.Button button7;
          private System.Windows.Forms.Button button8;
          private System.Windows.Forms.Button button9;
     }
}