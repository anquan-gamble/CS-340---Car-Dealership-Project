﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CarDealer
{
     public partial class Login : Form
     {
          public Login()
          {
               MySqlConnection con = new MySqlConnection();
               con.ConnectionString = "Server=localhost; database=new_schema; userid=root;password=password1!";
               InitializeComponent();
          }
          public static string username;
          public static string recby
          {
               get { return username; }
               set { username = value; }
          }
          private void textBox1_TextChanged(object sender, EventArgs e)
          {

          }

          private void textBox2_TextChanged(object sender, EventArgs e)
          {

          }

          private void button1_Click(object sender, EventArgs e)
          {
               MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");


               MySqlCommand cmd = new MySqlCommand("select Employee_ID,Password, User_Role from login where Employee_ID='" + textBox1.Text + "'and Password='" + textBox2.Text + "'", con);
               MySqlDataAdapter da = new MySqlDataAdapter(cmd);
               DataTable dt = new DataTable();
               da.Fill(dt);
            

               if (dt.Rows.Count > 0)
               {
                    switch (dt.Rows[0]["User_Role"] as string)
                    {
                         case "Manager":
                              {
                                   recby = textBox1.Text;
                                   this.Hide();
                                   MainMan mmm = new MainMan();
                                   mmm.Show();
                                   break;
                              }
                         case "Sales":
                              {
                                   recby = textBox1.Text;
                                   this.Hide();
                                   Salesperson mm = new Salesperson();
                                   mm.Show();
                                   break;
                              }
                    }
               }
               else
               {
                    MessageBox.Show("Invalid Login please check username and password");
               }
               con.Close();
          
     }

          private void button2_Click(object sender, EventArgs e)
          {
               Application.Exit();
          }

          private void Login_Load(object sender, EventArgs e)
          {
               MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
               con.Open();
          }

          private void label1_Click(object sender, EventArgs e)
          {

          }
     }
}
