﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class ManIn : Form
     {
          public ManIn()
          {
               InitializeComponent();
          }
          
          private void button1_Click(object sender, EventArgs e)
          {

               MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
               con.Open();
               MySqlCommand cmd = new MySqlCommand();
               cmd.CommandType = System.Data.CommandType.Text;
               cmd.CommandText = "INSERT INTO inventory (`VIN`,`Year`,`Make`,`Model`,`Type`,`Color`,`Odometer`,`MSRP`,`Condition`,`Date_Received`) VALUES ('" + textBox1.Text + "' , '" + textBox2.Text + "' , '" + textBox3.Text + "' , '" + textBox4.Text + "' , '" + textBox5.Text + "' , '" + textBox6.Text + "' , '" + textBox7.Text + "' , '" + textBox8.Text + "' , '" + textBox9.Text + "', '" + textBox10.Text + "')";
               cmd.Connection = con;
               int a = cmd.ExecuteNonQuery();
               con.Close();
               
               if (a>0)
               {
                    MessageBox.Show("Car Added");
               }
          }

          private void button2_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          private void ManIn_Load(object sender, EventArgs e)
          {
               textBox10.Text = DateTime.Now.ToString("yyyy-MM-dd");
          }
     }
}
