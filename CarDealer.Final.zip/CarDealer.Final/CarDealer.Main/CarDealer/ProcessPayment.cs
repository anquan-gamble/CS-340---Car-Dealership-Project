﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class ProcessPayment : Form
     {
          public ProcessPayment()
          {
               InitializeComponent();
          }


          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
               Cash cash = new Cash();
               cash.ShowDialog();
               this.Show();
          }

          private void button3_Click(object sender, EventArgs e)
          {
               this.Hide();
               Check check = new Check();
               check.ShowDialog();
               this.Show();
          }


          private void button6_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Cash Payment Only, Enter 0 for Trade-In Value");
          }


          private void button7_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Check Payment Only, Enter 0 for Trade-In Value");
          }

          private void button9_Click(object sender, EventArgs e)
          {
               this.Hide();
          }
     }
}
