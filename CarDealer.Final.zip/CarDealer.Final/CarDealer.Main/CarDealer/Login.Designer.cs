﻿namespace CarDealer
{
     partial class Login
     {
          /// <summary>
          /// Required designer variable.
          /// </summary>
          private System.ComponentModel.IContainer components = null;

          /// <summary>
          /// Clean up any resources being used.
          /// </summary>
          /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
          protected override void Dispose(bool disposing)
          {
               if (disposing && (components != null))
               {
                    components.Dispose();
               }
               base.Dispose(disposing);
          }

          #region Windows Form Designer generated code

          /// <summary>
          /// Required method for Designer support - do not modify
          /// the contents of this method with the code editor.
          /// </summary>
          private void InitializeComponent()
          {
               this.button1 = new System.Windows.Forms.Button();
               this.button2 = new System.Windows.Forms.Button();
               this.textBox1 = new System.Windows.Forms.TextBox();
               this.textBox2 = new System.Windows.Forms.TextBox();
               this.label1 = new System.Windows.Forms.Label();
               this.Password = new System.Windows.Forms.Label();
               this.label3 = new System.Windows.Forms.Label();
               this.SuspendLayout();
               // 
               // button1
               // 
               this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button1.ForeColor = System.Drawing.Color.White;
               this.button1.Location = new System.Drawing.Point(262, 350);
               this.button1.Name = "button1";
               this.button1.Size = new System.Drawing.Size(66, 32);
               this.button1.TabIndex = 0;
               this.button1.Text = "Login";
               this.button1.UseVisualStyleBackColor = false;
               this.button1.Click += new System.EventHandler(this.button1_Click);
               // 
               // button2
               // 
               this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
               this.button2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.button2.ForeColor = System.Drawing.Color.White;
               this.button2.Location = new System.Drawing.Point(394, 350);
               this.button2.Name = "button2";
               this.button2.Size = new System.Drawing.Size(66, 32);
               this.button2.TabIndex = 1;
               this.button2.Text = "Exit";
               this.button2.UseVisualStyleBackColor = false;
               this.button2.Click += new System.EventHandler(this.button2_Click);
               // 
               // textBox1
               // 
               this.textBox1.Location = new System.Drawing.Point(394, 150);
               this.textBox1.Name = "textBox1";
               this.textBox1.Size = new System.Drawing.Size(218, 22);
               this.textBox1.TabIndex = 2;
               this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
               // 
               // textBox2
               // 
               this.textBox2.Location = new System.Drawing.Point(394, 250);
               this.textBox2.Name = "textBox2";
               this.textBox2.PasswordChar = '*';
               this.textBox2.Size = new System.Drawing.Size(218, 22);
               this.textBox2.TabIndex = 3;
               this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
               // 
               // label1
               // 
               this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
               this.label1.AutoSize = true;
               this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
               this.label1.ForeColor = System.Drawing.Color.White;
               this.label1.Location = new System.Drawing.Point(175, 150);
               this.label1.Name = "label1";
               this.label1.Size = new System.Drawing.Size(155, 29);
               this.label1.TabIndex = 4;
               this.label1.Text = "Empoyee ID";
               this.label1.Click += new System.EventHandler(this.label1_Click);
               // 
               // Password
               // 
               this.Password.AutoSize = true;
               this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.Password.ForeColor = System.Drawing.Color.White;
               this.Password.Location = new System.Drawing.Point(175, 250);
               this.Password.Name = "Password";
               this.Password.Size = new System.Drawing.Size(128, 29);
               this.Password.TabIndex = 5;
               this.Password.Text = "Password";
               // 
               // label3
               // 
               this.label3.AutoSize = true;
               this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.label3.ForeColor = System.Drawing.Color.White;
               this.label3.Location = new System.Drawing.Point(219, 34);
               this.label3.Name = "label3";
               this.label3.Size = new System.Drawing.Size(289, 36);
               this.label3.TabIndex = 6;
               this.label3.Text = "The Car Dealership";
               // 
               // Login
               // 
               this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
               this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
               this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
               this.ClientSize = new System.Drawing.Size(700, 450);
               this.Controls.Add(this.label3);
               this.Controls.Add(this.Password);
               this.Controls.Add(this.label1);
               this.Controls.Add(this.textBox2);
               this.Controls.Add(this.textBox1);
               this.Controls.Add(this.button2);
               this.Controls.Add(this.button1);
               this.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
               this.Name = "Login";
               this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
               this.Text = "Login";
               this.Load += new System.EventHandler(this.Login_Load);
               this.ResumeLayout(false);
               this.PerformLayout();

          }

          #endregion

          private System.Windows.Forms.Button button1;
          private System.Windows.Forms.Button button2;
          private System.Windows.Forms.TextBox textBox1;
          private System.Windows.Forms.TextBox textBox2;
          private System.Windows.Forms.Label label1;
          private System.Windows.Forms.Label Password;
          private System.Windows.Forms.Label label3;
     }
}