﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{

    
     public partial class ViewInventory : Form
     {
         
           MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
          DataTable dt = new DataTable();

          public ViewInventory()
          {
               InitializeComponent();
          }
          public static string vin;
          public static string rere
          {
               get { return vin; }
               set { vin = value; }
          }
          private void Inventory_Load(object sender, EventArgs e)
          {
               
               con.Open();
               MySqlCommand command = new MySqlCommand("SELECT * FROM inventory GROUP BY `Make` ", con);
               MySqlDataAdapter da = new MySqlDataAdapter(command);
               DataTable dt = new DataTable();
               da.Fill(dt);
               foreach (DataRow dr in dt.Rows)
               {

                    comboBox1.Items.Add(dr["Make"].ToString());
               }
               
          }
          private DataTable GetInventoryList()
          {
               
               
               MySqlCommand command = new MySqlCommand("SELECT * FROM inventory WHERE Make = '" + comboBox1.SelectedItem + "'AND Model = '" + comboBox2.SelectedItem + "'; ", con);
               DataTable dt = new DataTable();
               MySqlDataReader reader = command.ExecuteReader();
               dt.Load(reader);
               return dt;
          }

          private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
          {

               
          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          

        

          private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
          {
               
          }

          private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
          {

          }
          private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
          {
               //GET OUR COMBO OBJECT
               comboBox1 = e.Control as ComboBox;
               if (comboBox1 != null)
               {
                    // AVOID ATTACHMENT TO MULTIPLE EVENT HANDLERS
                    comboBox1.SelectedIndexChanged -= new EventHandler(comboBox1_SelectedIndexChanged);

                    //THEN NOW ADD
                    comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
               }
          }

          private void comboBox1_Click(object sender, EventArgs e)
          {
               
          }

          private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
          {
               
               
          }

          private void comboBox2_SelectedValueChanged(object sender, EventArgs e)
          {
               dataGridView1.DataSource = GetInventoryList();
               comboBox2.Items.Clear();
          }

          private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
          {
               if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    dataGridView1.CurrentRow.Selected = true;
                    rere = dataGridView1.Rows[e.RowIndex].Cells["VIN"].FormattedValue.ToString();
               this.Hide();
               ProcessPayment man = new ProcessPayment();
               man.ShowDialog();
               this.Show();
          }

          private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
          {
               
               MySqlCommand command = new MySqlCommand("SELECT * FROM inventory WHERE Make = '" + comboBox1.SelectedItem + "' GROUP BY Model ", con);
               MySqlDataAdapter da = new MySqlDataAdapter(command);
               DataTable dt = new DataTable();
               da.Fill(dt);
               
               foreach (DataRow dr in dt.Rows)
               {
                    comboBox2.Items.Add(dr["Model"].ToString());


               }
               
          }
     }
}
