﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class netpay : Form
     {
          MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
          public netpay()
          {
               InitializeComponent();
          }


          private void button1_Click(object sender, EventArgs e)
          {
               // Variables
               double salary, commission;
               double grossPay, fedTax, stateTax, netPay, com;

               // input
               salary = Convert.ToDouble(txtRate.Text);
               commission = Convert.ToDouble(textBox12.Text);

               // calculations
               
               if (commission > 200000)
               {
                    com = commission * 0.1;
               }
               else if (commission >= 100000)
               {
                    com = commission * 0.07;
               }
               else 
               {
                   com = commission * 0.05;
               }
               grossPay = salary + com;
               fedTax = grossPay * 0.15;
               stateTax = grossPay * 5 / 100;
               netPay = grossPay - (fedTax + stateTax);

               //Display output of calculations
               txtGross.Text = grossPay.ToString("c");
               txtFed.Text = fedTax.ToString("c");
               txtState.Text = stateTax.ToString("c");
               txtNet.Text = netPay.ToString("c");
          }

          private void Form1_Load(object sender, EventArgs e)
          {

          }

          private void button2_Click(object sender, EventArgs e)
          {
               this.Hide();
          }

          private void textBox12_TextChanged(object sender, EventArgs e)
          {

          }

          private void txtHours_TextChanged(object sender, EventArgs e)
          {

          }

          private void txtRate_TextChanged(object sender, EventArgs e)
          {

          }
        

          private void textBox3_TextChanged(object sender, EventArgs e)
          {

          }

          private void textBox5_TextChanged(object sender, EventArgs e)
          {

          }

          private void txtNet_TextChanged(object sender, EventArgs e)
          {

          }

          private void button3_Click(object sender, EventArgs e)
          {
               con.Open();
               MySqlCommand command = new MySqlCommand("SELECT * FROM Employee WHERE Employee_ID = '" + textBox5.Text + "'", con);
               MySqlDataAdapter da = new MySqlDataAdapter(command);
               DataTable dt = new DataTable();
               da.Fill(dt);
               foreach (DataRow dr in dt.Rows)
               {
                    textBox3.Text = dr["First_Name"].ToString() + " " + dr["Last_Name"].ToString();
                    txtRate.Text = dr["Salary"].ToString();
               }
          }

          private void button4_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Check Printed");
          }
     }
}
