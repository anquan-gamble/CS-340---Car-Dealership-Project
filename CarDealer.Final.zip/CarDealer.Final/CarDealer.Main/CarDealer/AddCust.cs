﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDealer
{
     public partial class AddCust : Form
     {
          public AddCust()
          {
               InitializeComponent();
          }

          private void button1_Click(object sender, EventArgs e)
          {
               this.Hide();
               
          }

          private void button2_Click(object sender, EventArgs e)
          {
               try { 
               MySqlConnection con = new MySqlConnection("Server=localhost; database=new_schema; userid=root;password=password1!");
               con.Open();
               MySqlCommand cmd = new MySqlCommand();
               cmd.CommandType = System.Data.CommandType.Text;
               cmd.CommandText = "INSERT INTO customer (`License_Number`,`Last_Name`,`First_Name`,`Address`,`Sex`,`Phone_Number`,`Date_Of_Birth`,`Email`) VALUES ('" + textBox1.Text + "' , '" + textBox3.Text + "' , '" + textBox2.Text + "' , '" + textBox4.Text + "' , '" + textBox5.Text + "' , '" + textBox6.Text + "' , '" + textBox7.Text + "' , '" + textBox8.Text + "')";
               cmd.Connection = con;
               int a = cmd.ExecuteNonQuery();
               con.Close();

               if (a > 0)
               {
                    MessageBox.Show("Customer Added");
               }
               }
               catch (System.Exception)
               {
                    MessageBox.Show("Date Format yyyy-mm-dd");
               }

          }

          private void button3_Click(object sender, EventArgs e)
          {
               MessageBox.Show("Date format is yyyy-mm-dd");
          }
     }
}
