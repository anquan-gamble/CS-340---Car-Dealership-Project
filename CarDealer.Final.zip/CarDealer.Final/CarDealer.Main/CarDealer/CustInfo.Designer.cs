﻿namespace CarDealer
{
     partial class CustInfo
     {
          /// <summary>
          /// Required designer variable.
          /// </summary>
          private System.ComponentModel.IContainer components = null;

          /// <summary>
          /// Clean up any resources being used.
          /// </summary>
          /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
          protected override void Dispose(bool disposing)
          {
               if (disposing && (components != null))
               {
                    components.Dispose();
               }
               base.Dispose(disposing);
          }

          #region Windows Form Designer generated code

          /// <summary>
          /// Required method for Designer support - do not modify
          /// the contents of this method with the code editor.
          /// </summary>
          private void InitializeComponent()
          {
               this.components = new System.ComponentModel.Container();
               this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
               this.new_schemaDataSet1 = new CarDealer.new_schemaDataSet1();
               this.customerTableAdapter = new CarDealer.new_schemaDataSet1TableAdapters.customerTableAdapter();
               this.button1 = new System.Windows.Forms.Button();
               this.button2 = new System.Windows.Forms.Button();
               this.button3 = new System.Windows.Forms.Button();
               ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).BeginInit();
               this.SuspendLayout();
               // 
               // customerBindingSource
               // 
               this.customerBindingSource.DataMember = "customer";
               this.customerBindingSource.DataSource = this.new_schemaDataSet1;
               // 
               // new_schemaDataSet1
               // 
               this.new_schemaDataSet1.DataSetName = "new_schemaDataSet1";
               this.new_schemaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
               // 
               // customerTableAdapter
               // 
               this.customerTableAdapter.ClearBeforeFill = true;
               // 
               // button1
               // 
               this.button1.Location = new System.Drawing.Point(12, 12);
               this.button1.Name = "button1";
               this.button1.Size = new System.Drawing.Size(142, 23);
               this.button1.TabIndex = 1;
               this.button1.Text = "Go Back";
               this.button1.UseVisualStyleBackColor = true;
               this.button1.Click += new System.EventHandler(this.button1_Click);
               // 
               // button2
               // 
               this.button2.Location = new System.Drawing.Point(310, 137);
               this.button2.Name = "button2";
               this.button2.Size = new System.Drawing.Size(240, 23);
               this.button2.TabIndex = 2;
               this.button2.Text = "Add Customer";
               this.button2.UseVisualStyleBackColor = true;
               this.button2.Click += new System.EventHandler(this.button2_Click);
               // 
               // button3
               // 
               this.button3.Location = new System.Drawing.Point(310, 202);
               this.button3.Name = "button3";
               this.button3.Size = new System.Drawing.Size(240, 23);
               this.button3.TabIndex = 3;
               this.button3.Text = "View Customers";
               this.button3.UseVisualStyleBackColor = true;
               this.button3.Click += new System.EventHandler(this.button3_Click);
               // 
               // CustInfo
               // 
               this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
               this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
               this.BackColor = System.Drawing.SystemColors.ActiveCaption;
               this.ClientSize = new System.Drawing.Size(866, 450);
               this.Controls.Add(this.button3);
               this.Controls.Add(this.button2);
               this.Controls.Add(this.button1);
               this.Name = "CustInfo";
               this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
               this.Text = "CustInfo";
               this.Load += new System.EventHandler(this.CustInfo_Load);
               ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
               ((System.ComponentModel.ISupportInitialize)(this.new_schemaDataSet1)).EndInit();
               this.ResumeLayout(false);

          }

          #endregion
          private new_schemaDataSet1 new_schemaDataSet1;
          private System.Windows.Forms.BindingSource customerBindingSource;
          private new_schemaDataSet1TableAdapters.customerTableAdapter customerTableAdapter;
          private System.Windows.Forms.Button button1;
          private System.Windows.Forms.Button button2;
          private System.Windows.Forms.Button button3;
     }
}